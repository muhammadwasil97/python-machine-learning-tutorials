<?php
$hook_version = 1;
$hook_array = Array();
$hook_array['before_save'] = Array();
$hook_array['before_save'][] = Array(
    1,
    'Populate User Access And Permission Table',
    'modules/csrep_UserAccessReport/UserAccessPermisionTable.php',
    'UserAccessPermisionTable',
    'populateTable'
);