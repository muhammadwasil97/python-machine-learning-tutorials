<?php 

class FailedLoginAttempts 
{
    public function exportCSV()
    {
        $filename = "failed_login_attempts_export_" . date("Ymd_His") . ".txt";

        // Set headers to force download
        header('Content-Type: text');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        $logs = shell_exec("grep -i 'FAILED LOGIN' suitecrm*.log");

        fputs($output, $logs);

        fclose($output);

        exit();

    }
}

// Call the export function
$export = new FailedLoginAttempts();
$export->exportCSV();