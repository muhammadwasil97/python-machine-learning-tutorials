<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class UserAccessReportAccessLogsCsvExport
{
    public function exportCSV()
    {
        global $db;

        // Define the filename for the CSV file
        $filename = "user_access_and_permissions_logs_export_" . date("Ymd_His") . ".csv";
        $enabledModules = $GLOBALS['moduleList'];

        // Set headers to force download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        // Open output stream
        $output = fopen('php://output', 'w');

        // Output the column headings
        fputcsv($output, array('Role Name','Modified By', 'Permissions', 'Date Modified', 'Module Name', 'Permission Modification'));

        // Fetch data from your custom table
        $query = "
            SELECT r.name AS `role_name`, u.user_name, aa.name AS permission, ara.date_modified, 
            aa.category AS module_name,
            CASE
                    WHEN ara.access_override = 90 AND aa.name = 'view' OR aa.name = 'list' OR aa.name = 'export' OR aa.name = 'import'
                    THEN 'All'
                    WHEN ara.access_override = 90 OR ara.access_override = 89 AND aa.name = 'access'
                    THEN 'Enabled'
                    WHEN ara.access_override = 75 OR ara.access_override = 1
                    THEN 'Owner'
                    WHEN ara.access_override = 2 OR ara.access_override = 80
                    THEN 'Group'
                    WHEN ara.access_override = 3
                    THEN 'All'
                    WHEN ara.access_override = -99
                    THEN 'None'
                WHEN ara.access_override = 0
                    THEN 'Not Set'
                END AS `changes_made` 
            FROM acl_roles_actions ara 
            JOIN acl_actions aa ON ara.action_id = aa.id
            JOIN users u ON u.id = aa.modified_user_id
            JOIN acl_roles r ON ara.role_id=r.id
            WHERE u.deleted = 0 AND ara.access_override !=0 AND u.status = 'Active'
            ORDER BY r.name, aa.category
        ";
        $result = $db->query($query);

        // Output each row of the data
        $setRoleName = '';
        while ($row = $db->fetchByAssoc($result)) {
            if(in_array($row['module_name'], $enabledModules) == true) {
                if($row['role_name'] == $setRoleName) {
                    $row['role_name'] = '';
                } else {
                    $setRoleName = $row['role_name'];
                }
                $moduleNameArray = explode("_", $row['module_name']);
                $row['module_name'] = end($moduleNameArray);
    
                fputcsv($output, $row);
            }
        }

        // Close output stream
        fclose($output);
        exit();
    }
}

// Call the export function
$export = new UserAccessReportAccessLogsCsvExport();
$export->exportCSV();