<?php

require_once('include/MVC/Controller/SugarController.php');

class csrep_UserAccessReportController extends SugarController
{
    function action_editview()
    {
        // Disable Create View
        $this->view = 'noaccess';
    }

    function action_exportCsv()
    {
        require_once('modules/csrep_UserAccessReport/UserAccessReportCsvExport.php');
    }

    function action_userAccessLogs()
    {
        $this->view = 'accesslogs';
    }

    function action_exportAccessLogsCsv()
    {
        require_once('modules/csrep_UserAccessReport/UserAccessReportAccessLogsCsvExport.php');
    }

    function action_exportFailedLoginAttempts()
    {
        require_once('modules/csrep_UserAccessReport/FailedLoginAttempts.php');
    }

    function action_onedriveBackupLogs()
    {
        $filename = "onedrive_backup_logs" . date("Ymd_His") . ".txt";

        // Set headers to force download
        header('Content-Type: text');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        $logs = shell_exec("cat onedrive_backup.log");

        fputs($output, $logs);

        fclose($output);

        exit();
    }

    function action_loginAttempts()
    {
        $this->view = 'loginlogs';
    }

    function action_exportLoginAttempts()
    {
        global $db;

        // Define the filename for the CSV file
        $filename = "login_attempts_" . date("Ymd_His") . ".csv";
        $enabledModules = $GLOBALS['moduleList'];

        // Set headers to force download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        // Open output stream
        $output = fopen('php://output', 'w');

        // Output the column headings
        fputcsv($output, array('User Name', 'IP Address','User Agent','Event Type', 'Event Time'));

        // Fetch data from your custom table
        $query = "SELECT user_name, ip_address, user_agent, event_type, event_time FROM login_audit2;";
        $result = $db->query($query);

        // Output each row of the data
        while ($row = $db->fetchByAssoc($result)) {
              
            fputcsv($output, $row);
            
        }

        // Close output stream
        fclose($output);
        exit();
    }

    public function action_rolesEdit()
    {
        $this->view = 'rolesedit';
    }

    public function action_exportRolesEdit()
    {
        global $db;

        // Define the filename for the CSV file
        $filename = "role_changes_logs_" . date("Ymd_His") . ".csv";
        // Set headers to force download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        // Open output stream
        $output = fopen('php://output', 'w');

        // Output the column headings
        fputcsv($output, array('Role Name','Modified By', 'Date Modified'));

        // Fetch data from your custom table
        $query = "SELECT custom_aclroles_audit.role_name,users.user_name, 
        custom_aclroles_audit.date_modified
        FROM custom_aclroles_audit 
        JOIN users ON users.id = custom_aclroles_audit.modified_by;";
        $result = $db->query($query);

        // Output each row of the data
        while ($row = $db->fetchByAssoc($result)) {
              
            fputcsv($output, $row);
            
        }

        // Close output stream
        fclose($output);
        exit();
    }

    public function action_UsersCount()
    {
        $this->view = 'usermodule';
    }

    public function action_exportUsersCount()
    {
        global $db;

        // Define the filename for the CSV file
        $filename = "role_modules_users_" . date("Ymd_His") . ".csv";
        // Set headers to force download
        $enabledModules = $GLOBALS['moduleList'];
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        // Open output stream
        $output = fopen('php://output', 'w');

        // Output the column headings
        fputcsv($output, array('Role Name','Modules Used', 'Users Count'));

        // Fetch data from your custom table
        $query = "SELECT roles.name AS role_name,  (SELECT GROUP_CONCAT(DISTINCT  actions.category)
            FROM acl_roles roles2
            JOIN acl_roles_actions roles_actions ON roles_actions.role_id = roles2.id
            JOIN acl_actions actions ON actions.id = roles_actions.action_id
            WHERE roles.id = roles2.id AND (roles_actions.access_override != 0 OR roles_actions.access_override != -98
            OR roles_actions.access_override != -99)
            GROUP BY roles.id
            ) AS modules_used , 
            COUNT(users.id) AS users_count FROM acl_roles roles
            JOIN acl_roles_users roles_users ON roles.id = roles_users.role_id
            JOIN users ON roles_users.user_id = users.id
            WHERE users.deleted = 0 AND users.is_admin = 0 AND users.status = 'Active' 
            GROUP BY roles.id";
        $result = $db->query($query);

        // Output each row of the data
        while ($row = $db->fetchByAssoc($result)) {
            $modules_used = explode(",", $row['modules_used']);
            $filteredModules = '';
            foreach($modules_used as $used) {
                if(in_array($used, $enabledModules) == true) {
                    $moduleNameArray = explode("_", $used);
                    $filteredModules .=  end($moduleNameArray);
                    $filteredModules .= ', ';
                }
               
            }
            $row['modules_used'] = $filteredModules;
            fputcsv($output, $row);
            
        }

        // Close output stream
        fclose($output);
        exit();
    }

    public function action_exportAccessLog()
    {
        $filename = "role_changes_and_permissions_logs_" . date("Ymd_His") . ".txt";

        // Set headers to force download
        header('Content-Type: text');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        $logs = shell_exec('grep -E "SELECT acl_roles.*|UPDATE acl_roles_actions" suitecrm*.log');

        fputs($output, $logs);

        fclose($output);

        exit();
    }

    public function action_DbDetails()
    {
        $this->view = 'dbdetails';
    }
}