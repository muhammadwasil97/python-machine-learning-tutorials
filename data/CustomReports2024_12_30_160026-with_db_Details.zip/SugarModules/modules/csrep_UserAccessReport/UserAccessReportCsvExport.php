<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class UserAccessReportCsvExport
{
    public function exportCSV()
    {
        global $db;

        // Define the filename for the CSV file
        $filename = "user_roles_export_" . date("Ymd_His") . ".csv";
        $enabledModules = $GLOBALS['moduleList'];

        // Set headers to force download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        // Open output stream
        $output = fopen('php://output', 'w');

        // Output the column headings
        fputcsv($output, array('User Name', 'Full Name','Module Name','Role Name', 'Permissions'));

        // Fetch data from your custom table
        $query = "SELECT
users.user_name AS username,
CONCAT(users.first_name, ' ', users.last_name) AS full_name,
    actions.category AS module_name,
    roles.name AS role_name,
    actions.name AS permissions
    FROM
        users
    INNER JOIN
        acl_roles_users AS roles_users ON users.id = roles_users.user_id AND roles_users.deleted = 0
    INNER JOIN
        acl_roles AS roles ON roles_users.role_id = roles.id AND roles.deleted = 0
    INNER JOIN
        acl_roles_actions AS roles_actions ON roles.id = roles_actions.role_id AND roles_actions.deleted = 0
    INNER JOIN
        acl_actions AS actions ON roles_actions.action_id = actions.id AND actions.deleted = 0
    WHERE
        users.deleted = 0 AND roles_actions.access_override !=0 AND users.status = 'Active'
    ORDER BY
        users.user_name, roles.name, actions.category";
        $result = $db->query($query);

        // Output each row of the data
        $setUserName = "";
        $setFullName = '';
        while ($row = $db->fetchByAssoc($result)) {
            if(in_array($row['module_name'], $enabledModules) == true) {
                if($row['username'] == $setUserName) {
                    $row['username'] = '';
                } else {
                    $setUserName = $row['username'];
                }
                
                if($row['full_name'] == $setFullName) {
                    $row['full_name'] = '';
                } else {
                    $setFullName = $row['full_name'];
                }
                $moduleNameArray = explode("_", $row['module_name']);
                $row['module_name'] = end($moduleNameArray);
    
                fputcsv($output, $row);
            }
            
        }

        // Close output stream
        fclose($output);
        exit();
    }
}

// Call the export function
$export = new UserAccessReportCsvExport();
$export->exportCSV();