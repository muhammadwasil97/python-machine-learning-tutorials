<?php

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class CustomTableHandler
{
    function populateTable($bean, $event, $arguments)
    {
        global $db;

        $query = "SELECT users.id AS user_id, users.user_name, acl_roles.id AS role_id, acl_roles.name AS role_name 
                  FROM users
                  LEFT JOIN acl_roles_users ON acl_roles_users.user_id = users.id
                  LEFT JOIN acl_roles ON acl_roles.id = acl_roles_users.role_id
                  WHERE users.deleted = 0 AND acl_roles.deleted = 0";

        $results = $db->query($query);
    }
}
