<?php
$dictionary['csrep_UserAccessReport']['importable'] = false;