const remove = () => document.querySelectorAll('.actionmenulinks').forEach(el => el.remove());

remove();