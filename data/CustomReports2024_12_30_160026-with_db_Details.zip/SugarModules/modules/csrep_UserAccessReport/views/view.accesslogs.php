<?php

require_once('include/MVC/View/views/view.list.php');

class csrep_UserAccessReportViewAccessLogs extends ViewList {
    function display()
    {
        global $db;

        parent::display();

        echo "<style>
            #actionMenuSidebar, .listViewEmpty {
                display: none !important;
            }
            </style>";

        $exportUrl = 'index.php?module=csrep_UserAccessReport&action=exportAccessLog';
        echo '<div style="margin-top: 20px;">';
        echo '<a href="' . $exportUrl . '" class="button">Export to CSV</a>';
        echo '</div>';


    }
}