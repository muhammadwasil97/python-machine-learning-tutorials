<?php

require_once('include/MVC/View/views/view.list.php');

class csrep_UserAccessReportViewList extends ViewList
{
    function display()
    {
        global $db;

        parent::display();
        $enabledModules = $GLOBALS['moduleList'];

        $query = "SELECT
users.user_name AS username,
CONCAT(users.first_name, ' ', users.last_name) AS full_name,
     actions.name AS permissions,
    users.id AS user_id,
    actions.category AS module_name,
    roles.name AS role_name,
    CASE
    	WHEN roles_actions.access_override = 90 AND actions.name = 'view' OR actions.name = 'list' OR actions.name = 'export' OR actions.name = 'import'
    	THEN 'All'
    	WHEN roles_actions.access_override = 90 OR roles_actions.access_override = 89 AND actions.name = 'access'
    	THEN 'Enabled'
    	WHEN roles_actions.access_override = 75 OR roles_actions.access_override = 1
    	THEN 'Owner'
    	WHEN roles_actions.access_override = 2 OR roles_actions.access_override = 80
    	THEN 'Group'
    	WHEN roles_actions.access_override = 3
    	THEN 'All'
    	WHEN roles_actions.access_override = -99
    	THEN 'None'
   	WHEN roles_actions.access_override = 0
    	THEN 'Not Set'
    END AS access_level
    FROM
        users
    INNER JOIN
        acl_roles_users AS roles_users ON users.id = roles_users.user_id AND roles_users.deleted = 0
    INNER JOIN
        acl_roles AS roles ON roles_users.role_id = roles.id AND roles.deleted = 0
    INNER JOIN
        acl_roles_actions AS roles_actions ON roles.id = roles_actions.role_id AND roles_actions.deleted = 0
    INNER JOIN
        acl_actions AS actions ON roles_actions.action_id = actions.id AND actions.deleted = 0
    WHERE
        users.deleted = 0 AND roles_actions.access_override !=0 AND users.is_admin = 0 AND users.status = 'Active'
    ORDER BY
        users.user_name, roles.name, actions.category";
        $result = $db->query($query);
        echo "<style>
            #actionMenuSidebar, .listViewEmpty {
                display: none !important;
            }
            </style>";
        echo "<script src='modules/csrep_UserAccessReport/custom_js/remove_import_and_create_button.js'></script>";
        
        echo '<link href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
            <script src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>';


        $exportUrl = 'index.php?module=csrep_UserAccessReport&action=exportCSV';
        echo '<div style="margin-top: 20px;">';
        echo '<a href="' . $exportUrl . '" class="button">Export to CSV</a>';
        echo '</div>';

        // echo '<div style="margin-top: 20px;">';
        // echo '<a href="index.php?module=csrep_UserAccessReport&action=exportFailedLoginAttempts" class="button">Export Failed Login Attempts Logs</a>';
        // echo '</div>';

        echo '<div style="margin-top: 20px;">';
        echo '<a href="index.php?module=csrep_UserAccessReport&action=onedriveBackupLogs" class="button">One Drive Backup Logs</a>';
        echo '</div>';
        
        $usernames = [];

        while ($row = $db->fetchByAssoc($result)) {
            // Store each row in the array
            $data[] = $row;
        }

        foreach($data as $val) {
            $usernames[] = $val['username'];
        }

        $usernames = array_unique($usernames);

        foreach($usernames as $username) {
            echo '<div class="panel panel-default" >';
            
            echo '<div class="panel-heading">';

            echo '<a class="" role="button" data-toggle="collapse" href="#useraccessreport_report_'.$username.'" aria-expanded="false">
                    <div class="col-xs-10 col-sm-11 col-md-11">
                        '.strtoupper($username).'
                    </div>
                </a>';
            echo '</div>';
            
            echo '<div class="panel-body panel-collapse collapse in" id="useraccessreport_report_'.$username.'">';
            echo '<div class="tab-content">';
            echo '<div class="list-view-rounded-corners">';
            echo '<table class="list view table-responsive aor_reports">';
            echo '<thead>';
            echo '<tr>
                    <th scope="col">Module</th>
                    <th scope="col">Role Name</th>
                    <th scope="col">Permission</th>
                    <th scope="col">Access Level</th>
                </tr>';
            
            echo '</thead>';
    
            echo '<tbody>';

            foreach($data as $val) {
                if($val['username'] == $username && in_array($val['module_name'], $enabledModules) == true) {

                    $moduleNameArray = explode("_", $val['module_name']);
                    $moduleName = end($moduleNameArray);

                    echo '
                        <tr class="oddListRowS1">
                            <td>'.$moduleName.'</td>
                            <td>'.$val['role_name'].'</td>
                            <td>'.$val['permissions'].'</td>
                            <td>'.($val['access_level'] == null ? 'Not Set' : $val['access_level']).'</td>
                        </tr>
                    ';
                }
                
            }
            echo '</tbody>';

            echo '</table>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';

            echo '<script>
                    $(document).ready( function () {
                        $(".table-responsive").DataTable();
                    } );
                    </script>'; 
        }
    }
}