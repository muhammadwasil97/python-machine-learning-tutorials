<?php

require_once('include/MVC/View/views/view.list.php');

class csrep_UserAccessReportViewUserModule extends ViewList {
    function display()
    {
        global $db;

        parent::display();
        $enabledModules = $GLOBALS['moduleList'];
        $query = "
            SELECT roles.name AS role_name,  (SELECT GROUP_CONCAT(DISTINCT  actions.category)
            FROM acl_roles roles2
            JOIN acl_roles_actions roles_actions ON roles_actions.role_id = roles2.id
            JOIN acl_actions actions ON actions.id = roles_actions.action_id
            WHERE roles.id = roles2.id AND (roles_actions.access_override != 0 OR roles_actions.access_override != -98
            OR roles_actions.access_override != -99)
            GROUP BY roles.id
            ) AS modules_used , 
            COUNT(users.id) AS users_count FROM acl_roles roles
            JOIN acl_roles_users roles_users ON roles.id = roles_users.role_id
            JOIN users ON roles_users.user_id = users.id
            WHERE users.deleted = 0 AND users.is_admin = 0 AND users.status = 'Active' 
            GROUP BY roles.id; 
        ";

        $result = $db->query($query);

        echo "<style>
            #actionMenuSidebar, .listViewEmpty {
                display: none !important;
            }
            </style>";
        echo "<script src='modules/csrep_UserAccessReport/custom_js/remove_import_and_create_button.js'></script>";
        
        echo '<link href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
            <script src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>';


        $exportUrl = 'index.php?module=csrep_UserAccessReport&action=exportUsersCount';
        echo '<div style="margin-top: 20px;">';
        echo '<a href="' . $exportUrl . '" class="button">Export to CSV</a>';
        echo '</div>';

        echo '<div class="panel panel-default" >';
            
        echo '<div class="panel-heading">';

        echo '<a class="" role="button" data-toggle="collapse" href="#useraccessreport_report_accesslogs" aria-expanded="false">
                <div class="col-xs-10 col-sm-11 col-md-11">
                    User Access And Permission Logs
                </div>
            </a>';
        echo '</div>';
        
        echo '<div class="panel-body panel-collapse collapse in" id="useraccessreport_report_accesslogs">';
        echo '<div class="tab-content">';
        echo '<div class="list-view-rounded-corners">';
        echo '<table class="list view table-responsive aor_reports">';
        echo '<thead>';
        echo '<tr>
                <th scope="col">Role Name</th>
                <th scope="col">Module Used</th>
                <th scope="col">Users Count</th>
            </tr>';
        
        echo '</thead>';

        echo '<tbody>';

        while ($row = $db->fetchByAssoc($result)) {
            $modules_used = explode(",", $row['modules_used']);
            $filteredModules = '';
            foreach($modules_used as $used) {
                if(in_array($used, $enabledModules) == true) {
                    $moduleNameArray = explode("_", $used);
                    $filteredModules .=  end($moduleNameArray);
                    $filteredModules .= ', ';
                }
               
            }
            $row['modules_used'] = $filteredModules;
            echo '
                <tr class="oddListRowS1">
                    <td>'.$row['role_name'].'</td>
                    <td>'.$row['modules_used'].'</td>
                    <td>'.$row['users_count'].'</td>
                </tr>
            ';
        }

        echo '</tbody>';

        echo '</table>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';

        echo '<script>
                $(document).ready( function () {
                    $(".table-responsive").DataTable();
                } );
                </script>';
    }
}