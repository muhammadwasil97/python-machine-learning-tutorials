<?php

require_once('include/MVC/View/views/view.list.php');

class csrep_UserAccessReportViewDbDetails extends ViewList {
    function display()
    {
        global $db;

        parent::display();

        $query = "SELECT SUM( ROUND(((data_length + index_length) / 1024 / 1024), 2) )AS 'Size (MB)'
        FROM information_schema.TABLES
        WHERE table_schema = 'suitecrm'";

        $result = $db->query($query);

        while ($row = $db->fetchByAssoc($result)) {
            // Store each row in the array
            $data[] = $row;
        }

        echo "<style>
            #actionMenuSidebar, .listViewEmpty {
                display: none !important;
            }
            </style>";
        echo "<h3>SuiteCRM Total DB Size:".$data[0]['Size (MB)'] . " MB</h3><br>
        <br>";

        $queryTwo = "SELECT table_name AS 'Table',ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'Size (MB)'
        FROM information_schema.TABLES  WHERE table_schema = 'suitecrm'";

        $resultTwo = $db->query($queryTwo);

        while ($rowTwo = $db->fetchByAssoc($resultTwo)) {
            // Store each row in the array
            $dataTwo[] = $rowTwo;
            echo "Table: " . $rowTwo['Table'] . " Size: " . $rowTwo['Size (MB)'] . " MB<br>";
        }

        foreach ($dataTwo as $row) {
            echo "Table: " . $row['Table'] . ", Size: " . $row['Size (MB)'] . " MB<br>";
        }
    }
}