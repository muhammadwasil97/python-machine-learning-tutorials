<?php

require_once('include/MVC/View/views/view.list.php');

class csrep_UserAccessReportViewRolesEdit extends ViewList {
    function display()
    {
        global $db;

        parent::display();

        $query = "
            SELECT users.user_name, custom_aclroles_audit.* FROM custom_aclroles_audit 
            JOIN users ON users.id = custom_aclroles_audit.modified_by;
        ";

        $result = $db->query($query);

        echo "<style>
            #actionMenuSidebar, .listViewEmpty {
                display: none !important;
            }
            </style>";
        echo "<script src='modules/csrep_UserAccessReport/custom_js/remove_import_and_create_button.js'></script>";
        
        echo '<link href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
            <script src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>';


        $exportUrl = 'index.php?module=csrep_UserAccessReport&action=exportRolesEdit';
        echo '<div style="margin-top: 20px;">';
        echo '<a href="' . $exportUrl . '" class="button">Export to CSV</a>';
        echo '</div>';

        echo '<div class="panel panel-default" >';
            
        echo '<div class="panel-heading">';

        echo '<a class="" role="button" data-toggle="collapse" href="#useraccessreport_report_accesslogs" aria-expanded="false">
                <div class="col-xs-10 col-sm-11 col-md-11">
                    User Access And Permission Logs
                </div>
            </a>';
        echo '</div>';
        
        echo '<div class="panel-body panel-collapse collapse in" id="useraccessreport_report_accesslogs">';
        echo '<div class="tab-content">';
        echo '<div class="list-view-rounded-corners">';
        echo '<table class="list view table-responsive aor_reports">';
        echo '<thead>';
        echo '<tr>
                <th scope="col">Role Name</th>
                <th scope="col">Modified By</th>
                <th scope="col">Date Modified</th>
            </tr>';
        
        echo '</thead>';

        echo '<tbody>';

        while ($row = $db->fetchByAssoc($result)) {
            echo '
                <tr class="oddListRowS1">
                    <td>'.$row['role_name'].'</td>
                    <td>'.$row['user_name'].'</td>
                    <td>'.$row['date_modified'].'</td>
                </tr>
            ';
        }

        echo '</tbody>';

        echo '</table>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';

        echo '<script>
                $(document).ready( function () {
                    $(".table-responsive").DataTable();
                } );
                </script>';
    }
}